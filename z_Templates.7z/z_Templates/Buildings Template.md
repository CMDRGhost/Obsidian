---
aliases: 
tags:
  - Building
---
# Buildings Template
#z_Templates


# Details
## Generic
#### Parent Location
[[Geographic_Locations_
[[Settlements_
[[Buildings_
#### Construction Date
#### Date that became a ruin
#### Ruler / Owner
[[Characters_
#### Owning Organization
[[Organizations_
#### Alternative Name(s)
#### Organizations Contesting Ownership of the Landmark
[[Organizations_
#### Owning Rank
[[Ranks_Titles_
#### Purpose
#### Alterations
#### Architecture
#### Defenses
#### History
#### Tourism
## Room
#### Including Vehicle
[[Vehicles_
#### Connected Rooms
[[Buildings_
#### Design
#### Entries
#### Sensory & Appearances
#### Denizens
#### Contents & Furnishings
#### Valuables & Treasure
#### Hazards & Traps
#### Special Properties
#### Environment & Effects
