---
aliases: 
tags:
  - Condition
---
# Conditions Template
#z_Templates


# Details
#### Parent
[[Conditions_
#### Affected Species
[[Species_
#### Origin
#### Rarity
#### Cycle
#### Transmission / Vectors
#### Cause
#### Symptoms
#### Treatment
#### Prognosis
#### Sequela
*Which are the pathological conditions resulting from the condition? Are there any late stage or recouperation stage complications? Which conditions become more acute or likely after contracting this condition?*
#### Prevention
#### Epidemiology
#### History
#### Cultural Reception

#### Affected Groups
#### Hosts and Carriers
