---
aliases: 
tags:
  - Document
---
# Documents Template
#z_Templates


# Details
## Generic
#### Medium
#### Related Location
[[Geographic_Locations_
[[Settlements_
[[Buildings_
#### Related Myth
[[Myths_
#### Document Authors
[[Characters_
#### Signatories (Characters)
[[Characters_
#### Signatories (Organizations)
[[Organizations_
#### Purpose
## Structure
#### Clauses
#### Caveats
#### Legal Status
#### Publication Status
#### References
## Historical Details
#### Authoring Date
#### Ratification Date
#### Expiration Date
#### Background
#### History
#### Public Reaction
#### Legacy
#### Term
## Actual Contents
#### Contents
