---
aliases: 
tags:
  - Ethnicity
---
# Ethnicities Template
#z_Templates


# Details
## Naming Traditions
#### Family Names
#### Feminine Names
#### Masculine Names
#### Unisex Names
#### Other Names
## Ideals
#### Beauty Ideals
#### Gender Ideals#
#### Courtship Ideals
#### Relationship Ideals
## Customs
#### Customary Codes & Shared Values
#### Major Language Groups & Dialects
#### Common Etiquette
#### Dress Code
#### Art & Architecture
#### Foods & Cuisine
#### Culture & Cultural Heritage
#### Common Customs & Observed Traditions
#### Birth/Baptismal Rites
#### Coming of Age Rites
#### Funerary & Memorial Customs
#### Taboos
#### Myths & Legends
#### Major Historical Figures
#### Attained Technological Levels
## Connections & Relations
#### Related Locations
[[Geographic_Locations_
#### Parent Ethnicities
[[Ethnicities_
#### Major Organizations