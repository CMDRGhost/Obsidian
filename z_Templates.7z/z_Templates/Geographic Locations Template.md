---
aliases: 
tags:
  - Geographic_Location
---
# Geographic Locations Template
#z_Templates



# Details
#### Parent Location
[[Geographic_Locations_
#### Ruler / Owner
[[Characters_
#### Owning Rank
[[Ranks_Titles_
#### Owning Organization
[[Organizations_
#### Organizations Contesting Ownership of the Location
[[Organizations_
#### Alternative Name(s)
#### Geography
#### Ecosystem
#### Ecosystem Cycles
#### Localized Phenomena
#### Climate
#### Flora & Fauna
#### Natural resources
#### History
#### Tourism
