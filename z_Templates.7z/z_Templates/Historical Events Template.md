---
tags:
  - Historical_Event
aat-event-start-date: yyyy-mm-dd
aat-event-end-date: yyyy-mm-dd
aat-render-enabled: true
timelines:
  - timelines
Type Historical Event: 
Significance Historical Events:
---
# Historical Events Template
#z_Templates 


# Details
#### Significance
#### Type
#### Short Description/Excerpt
#### Full content
#### Related Characters
[[Characters_
#### Related Organizations
[[Organizations_
#### Related Article
#### Related Session Report
[[Session_Reports_
#### Related Location
[[Geographic_Locations_  
[[Settlements_  
[[Buildings_
#### Related Species
[[Species_


