---
aliases: 
tags:
  - Item
---
# Items Template
#z_Templates


# Details
## Generic
#### Weight
#### Dimensions
#### Base Price
#### Rarity
#### History
#### Creation Date
#### Destruction Date
#### Significance
#### Mechanics & Inner Workings
## Construction
#### Materials & Components
#### Tooling
#### Manufacturing Process
## Categorization
#### Modeled After / Subtype of
[[Items_
#### Manufacturer
[[Organizations_
#### Creator
[[Characters_
#### Owning Organization
[[Organizations_
#### Related Technologies
[[Technologies_
#### Related Condition
[[Conditions_
#### Related Ethnicities
[[Ethnicities_