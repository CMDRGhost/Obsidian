---
aliases: 
tags:
  - Language
---
# Languages Template
#z_Templates 


# Details
## General
#### Parent Languages
[[Languages_
#### Spoken by
[[Ethnicities_
## Structure
#### Phonology
#### Morphology
#### Syntax
#### Vocabulary
#### Writing System
#### Phonetics
#### Tenses
#### Sentence Structure
#### Adjective Order
#### Structural Markers
## Common Usage
#### Common Phrases
#### Common Female Names
#### Common Male Names
#### Common Unisex Names
#### Common Family Names
#### Geographic Distribution
## Dictionary
