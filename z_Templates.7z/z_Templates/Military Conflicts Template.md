---
aliases: 
tags:
  - Military_Conflict
---
# Military Conflicts Template
#z_Templates 


# Details
## Action
#### Start Date
#### End Date
#### Prelude
#### Deployment
#### Battlefield
#### Conditions
#### Engagement
## Repercussions
#### Result
#### Outcome / Short-Term Effects
#### Aftermath / Long-Term Effects
#### Legacy
#### History
#### Literature
#### Technology
## Specifications
#### Location Type
#### Parent Conflict
[[Military_Conflicts_
#### Location
[[Geographic_Locations_
#### Maps
## Conflict Sides
*Copy Template for every Side*
#### Coalition/Side Name
#### Strength
#### Casualties
#### Objectives
#### Organizations
[[Organizations_
#### Leaders
[[Characters_
