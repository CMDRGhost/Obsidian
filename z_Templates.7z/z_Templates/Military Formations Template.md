---
aliases: 
tags:
  - Military_Formation
---
# Military Formations Template
#z_Templates 


# Details
## Formation Flag/Crest
## Composition
#### Parent Formation
[[Military_Formations_
#### Assumed Veterancy
#### Overall Training Level
#### Used by
[[Organizations_
#### Related Ranks
[[Ranks_Titles_
#### Manpower
#### Equipment
#### Weaponry
#### Vehicles
#### Command Structure
#### Tactics
#### Training
## Logistics
#### Logistical Support
#### Auxilia
*Are there divisions not part of the formation which may nevertheless assist? For example, this formation might be able to call for air strikes or artillery bombardment.*
#### Upkeep
#### Recruitment
## History
#### Founding Date
#### Dissolution Date
#### History
#### Historical Loyalties