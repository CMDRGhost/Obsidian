---
aliases: 
tags:
  - Myth
---
# Myths Template
#z_Templates 


# Details
## Generic
#### Date of Recording
#### Date of Setting
#### Summary
#### Historical Basis
#### Spread / Apocrypha
#### Variations
#### Cultural Reception
#### In Literature
#### In Art
## Relations
#### Telling / Related Prose
[[Proses_
#### Related People
[[Characters_
#### Related Ethnicities
[[Ethnicities_
#### Related Species
[[Species_
#### Related Locations
[[Geographic_Locations_
#### Related Organizations
[[Organizations_
#### Related Items
[[Items_
#### Related Vehicles
[[Vehicles_