---
aliases: 
tags:
  - Organization
---
# Organizations Template
#z_Templates


# Details

## Generic
#### Motto / Slogan / Axiom
#### Alternative names
#### Demonym
/*Demonym is a word that identifies residents or natives of a particular place, which is derived from the name of that particular place. For example "French" is the demonym for someone from France.*/
#### Founding Date
#### Dissolution Date
#### Leader
[[Characters_
#### Ruling Organization
[[Organizations_
#### Leader Title
[[Ranks_Titles_
#### Founders
[[Characters_
#### Parent Organization
[[Organizations_
#### Geographic Location / Base Settlement / HQ
[[Geographic_Locations_
#### Related Species
[[Species_
#### Related Ethnicities
[[Ethnicities_
#### Organization structure
#### Culture
#### Public agenda
#### Assets
#### History
#### Disbandment
#### Predecessor Organizations
[[Organizations_
#### Successor Organizations
[[Organizations_
## Geopolitical
#### Capital
[[Geographic_Locations_
#### Head of State
[[Characters_
#### Head of Government
[[Characters_
#### Government System
#### Power Structure System
#### Economic System
#### Neighboring Geopolitical Organizations
[[Organizations_
#### Recognised/Official Languages
[[Languages_
#### Official State Religion
#### Important Locations (Gazetteer)
[[Geographic_Locations_
#### Official Currency
#### legislative Body
#### Judicial Body
#### Executive Body
#### Demography & Population
#### Foreign Relations
#### Laws
#### Territory
#### Military
#### Religion
#### Agriculture & Industry
#### Trade & Transport
#### Imports
#### Exports
#### Education
#### Infrastructure
#### Technological and Scientific Level
## Religious
#### Deities
[[Characters_
#### Mythology
#### Origins
#### Cosmology
#### Tenets of Faith
#### Priesthood
#### Ethics
#### Granted Divine Powers
#### Political Intrigue & Influence
#### Worship
#### Sects
## Military
#### Training Level
#### Veterancy
#### Weapons & Technology
