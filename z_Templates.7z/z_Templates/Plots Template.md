---
aliases: 
tags:
  - Plot
---
# Plots Template
#z_Templates 


# Details
## Generic
#### Parent Plot
[[Plots_
#### Related Characters
[[Characters_
#### Related Organizations
[[Organizations_
#### Related Locations
[[Geographic_Locations_  
[[Settlements_  
[[Buildings_
#### Plot/Story Type
#### Completion Date
#### Sub-Structures (Scenes)
#### Themes
## Structure
#### Exposition
#### Conflict
#### Rising Action
#### Climax
#### Falling Action
#### Resolution
## Components
#### Goals
#### Hooks
#### Stakes
#### Moral Quandaries
#### Cruel Tricks
#### Red Herrings
## Relations
#### Protagonists
#### Allies
#### Neutrals
#### Competitors
#### Adversaries
## Backdrops
#### Locations
#### Threats
#### Encounter
#### Past Events / Histories
