---
aliases: 
tags:
  - Profession
---
# Professions Template
#z_Templates


# Details
## Career
#### Qualifications
#### Career Progression
#### Payment & Reimbursement
#### Benefits
## Perception
#### Alternative Names
#### Demand
#### Purpose
#### Social Status
#### Demographics
#### History
## Operations
#### Tools
#### Materials
#### Workplace
#### Provided Services
#### Hazards
#### Legality
## Relations
#### Ranks & Titles
[[Ranks_Titles_
#### Related Locations
[[Geographic_Locations_
#### Famous in the Field
[[Characters_
#### Used By
[[Organizations_
#### Other Associated professions
[[Professions_
#### Related Vehicles
[[Vehicles_
#### Related Technologies
[[Technologies_
## Location
#### Current Geographic Location
[[Geographic_Locations_
#### Current Holder (Character)
[[Characters_