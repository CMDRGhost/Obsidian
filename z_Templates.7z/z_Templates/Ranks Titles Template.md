---
aliases: 
tags:
  - Rank_Title
---
# Ranks Titles Template
#z_Templates 


# Details
## Generic
#### Form of Address
#### Alternative Names
#### Report to...
[[Ranks_Titles_
#### Related Locations
[[Geographic_Locations_
[[Settlements_
[[Buildings_
#### Related Organizations
[[Organizations_
#### Source of Authority
#### Length of Term
#### Comparative Weight
#### Equates to
#### Qualifications
#### Requirements
#### Appointment
#### Duties
#### Responsibilities
#### Benefits
#### Accoutrements & Equipment
#### Removal or Dismissal
## Historical Details
#### Status
#### First Holder
[[Characters_
#### Current Holders
[[Charakters_
#### Past Holders
#### Creation
#### History
#### Cultural Significance
#### Notable Holders
