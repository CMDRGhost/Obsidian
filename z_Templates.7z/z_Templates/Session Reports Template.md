---
aliases: 
tags:
  - Session_Report
---
# Session Reports Template
#z_Templates 


# Details
#### Date
#### Related Campaign Session
[[Session_Reports_
#### Related Characters
[[Characters_
#### Related Plots
[[Plots_
#### Primary Location
[[Geographic_Locations_
[[Settlements_
[[Buildings_
#### Secondary Location
[[Geographic_Locations_
[[Settlements_
[[Buildings_
#### Rewards Granted
#### Missions/Quests Completed
#### Character(s) Interacted With
#### Created Content
#### Related Reports
#### Notes / Extra Material
