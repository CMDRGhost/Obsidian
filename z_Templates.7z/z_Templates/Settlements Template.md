---
aliases: 
tags:
  - Settlement
---
# Settlements Template
#z_Templates 


# Details
#### Parent Location
[[Geographic_Locations_
[[Settlements_
[[Buildings_
#### Founding Date
#### Founders
[[Characters_
#### Date that Became a Ruin
#### Ruler / Owner
[[Characters_
#### Additional Rulers/Owners
[[Characters_
#### Owning Rank
[[Ranks_Titles_
#### Owning Organization
[[Organizations_
#### Alternative Name(s)
#### Population
#### Inhabitants Demonym
#### Demographics
#### Government
#### Infrastructure
#### Districts
#### Assets
#### Defences
#### Industry and Trade
#### Guilds and Factions
#### History
#### Points of Interest
#### Tourism
#### Architecture
#### Geography
#### Climate
#### Natural Resources
