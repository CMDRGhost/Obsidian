---
aliases: 
tags:
  - Spell_Ability
---
# Spells Abilities Template
#z_Templates 


# Details
## Generic
#### Effect
#### Side/Secondary Effects
#### Manifestation
#### Source
#### Related Deity/Higher power
[[Characters_
#### Discovery
#### Related Organizations
[[Organizations_
## Technical Details
#### Material Components
#### Gestures & Rituals
#### Related Discipline
#### Related School
#### Related Element
#### Effect Duration
#### Casting Time
#### Range
#### Level
#### Applied Restrictions
