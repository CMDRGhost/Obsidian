---
aliases: 
tags:
  - Technology
---
# Technologies Template
#z_Templates 


# Details
#### Discovery
#### Access/Availability
#### Complexity
#### Utility
#### Manufacturing
#### Social Impact
#### Inventor
#### Related Species
[[Species_
#### Parent Technologies
[[Technologies_