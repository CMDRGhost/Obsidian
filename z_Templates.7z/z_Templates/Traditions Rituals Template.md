---
aliases: 
tags:
  - Tradition_Ritual
---
# Traditions Rituals Template
#z_Templates 


# Details
#### Primary Related Location
[[Geographic_Locations_ 
[[Settlements_ 
[[Buildings_
#### Important Locations
[[Geographic_Locations_ 
[[Settlements_ 
[[Buildings_
#### Related Organizations
[[Organizations_
#### Related Ethnicities
[[Ethnicities_
#### History
#### Execution
#### Components and Tools
#### Participants & Key Roles
#### Observance
