---
aliases: 
tags:
  - Vehicle
---
# Vehicles Template
#z_Templates 


# Details
## Identity
#### Class
[[Vehicles_
#### Owning Organization
[[Organizations_
#### Related Technologies
[[Technologies_
#### Current location
[[Geographic_Locations_ 
[[Settlements_  
[[Buildings_
#### Military Formation Usage
[[Military_Formations_
#### Manufacturer
[[Organizations_
#### Owner
[[Characters_
#### Nickname
#### Designation
#### Motto
#### Creation Date
#### Decommission Date
#### Destruction Date
## Properties
#### Price
#### Length
#### Width
#### Height
#### Weight
#### Rarity
#### Speed
#### Complement / Crew
#### Cargo & Passenger Capacity
## Systems
#### Power Generation
#### Propulsion
#### Weapons & Armament
#### Armor and Defense
#### Communication Tools & Systems
#### Sensors
#### Additional & Auxiliary Systems
#### Hangars & Docked Vessels